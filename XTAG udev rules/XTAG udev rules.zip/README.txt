To use your XTAG adaptor please move the 99-xmos.rules files into /etc/udev/rules.d/ directory.
